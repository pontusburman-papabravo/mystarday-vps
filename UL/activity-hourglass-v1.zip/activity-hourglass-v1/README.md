# Activity Hourglass v1

Färdig animerbar timglaskomponent för Min Stjärndag.

## Innehåll

- `hourglass.svg` – animerbar SVG med ram, glas, sand och reduced-motion.
- `hourglass-component.js` – minimalt API för appens timer-state.
- `demo.html` – fristående demo med start, paus, fortsätt, stopp och omstart.
- `preview.png` – statisk förhandsvisning.

## API

```js
const hourglass = new ActivityHourglass(svgElement);

hourglass.setState({
  remainingSeconds: 84,
  durationSeconds: 120,
  state: "running"
});
```

Tillåtna states: `idle`, `running`, `paused`, `finished`.

Komponenten driver ingen egen klocka. Den visar bara den timer-state som appen skickar in.
