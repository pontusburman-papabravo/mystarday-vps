export class ActivityHourglass {
  constructor(svgElement) {
    if (!(svgElement instanceof SVGElement)) {
      throw new TypeError("ActivityHourglass requires an SVGElement.");
    }
    this.svg = svgElement;
    this.setState({ remainingSeconds: 1, durationSeconds: 1, state: "idle" });
  }

  setProgress(value) {
    const progress = Math.max(0, Math.min(1, Number(value) || 0));
    this.svg.style.setProperty("--progress", progress.toFixed(4));
  }

  setRunning(isRunning) {
    this.svg.style.setProperty("--running", isRunning ? "1" : "0");
  }

  setState({ remainingSeconds, durationSeconds, state }) {
    const duration = Math.max(1, Number(durationSeconds) || 1);
    const remaining = Math.max(0, Math.min(duration, Number(remainingSeconds) || 0));
    this.setProgress(1 - remaining / duration);
    this.setRunning(state === "running" && remaining > 0);
  }
}
