# Barnets samling — theme tab icons

Detta paket innehåller 40 transparenta WebP-ikoner:

- 10 teman
- 4 flikikoner per tema
- 512 × 512 px
- transparent bakgrund
- konsekvent, lekdrivet formspråk

## Filnamn

- `icon-today@2x.webp`
- `icon-collection@2x.webp`
- `icon-treasure@2x.webp`
- `icon-family@2x.webp`

## Installation

Kopiera mappen `public/` till repo-roten. Filerna hamnar under:

`public/images/child/themes/<theme>/`

Behåll nuvarande emoji som fallback om en bild inte kan laddas.
