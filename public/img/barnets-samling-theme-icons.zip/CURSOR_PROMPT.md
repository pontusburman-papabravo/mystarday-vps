Du arbetar i `pontusburman-papabravo/mystarday-vps`.

Integrera de 40 tematiska flikikonerna i Barnets samling bakom `barnets_samling`.

ZIP-filen är stagingmaterial. Extrahera `public/images/child/themes/<theme>/icon-*.webp`
till repo-roten och ta bort ZIP-filen ur committed diff.

Krav:
- använd centrala asset-paths i `public/js/child-theme.js`
- fyra ikoner per canonical theme: today, collection, treasure, family
- använd bildikon när gate ON och asset finns
- behåll befintlig emoji som robust fallback
- gate OFF ska lämna legacy helt oförändrat
- läs aldrig `house_config.theme`
- lägg inte path-logik separat i varje flik
- ikonerna ska ha korrekt alt/aria-hantering; dekorativa bilder ska inte dubbelläsas
- undvik layout shift genom fasta dimensioner/aspect-ratio
- verifiera iPhone Safari/PWA och Android Chrome/PWA
- uppdatera SW/cache enligt repo-konvention
- lägg till tester för alla 40 paths, alias, fallback och gate
- kör `npm run test:gate`, `npm run check:css` och `node --test test/child-theme.test.js`

Scope:
- inga ändringar i reward/redeem, schema, bockning eller familjerelationer
- inget nytt föräldra-UI eller API i denna PR
- bakgrunderna från föregående paket ska fortsätta fungera
