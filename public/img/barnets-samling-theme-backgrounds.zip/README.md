# Barnets samling — theme backgrounds

Detta paket innehåller tio genererade bakgrunder för de kanoniska temana:

- adventure
- space
- dinosaurs
- vehicles
- animals
- ocean
- sports
- builders
- music
- arcade

## Placering

Kopiera mappen `public/` till repo-roten. Filerna hamnar då under:

`public/images/child/themes/<theme>/background@2x.webp`

## Innehåll

Detta paket innehåller endast bakgrunder. Flikikonerna ingår inte ännu.

Bakgrunderna är porträttbilder i cirka 9:16-format, WebP, utan text och med öppen yta för appens kort och navigation.

## Cursor

Verifiera att `public/js/child-theme.js` använder dessa paths. Lägg därefter till CSS som använder respektive bild via `background-image`, men behåll befintlig gradient som fallback. Använd inte fixed backgrounds. Säkerställ Android Chrome/PWA, iPhone Safari/PWA, safe-area, bottom-nav-padding och ingen horisontell scroll.
