# Barnets samling — aktivitetspictogram

Två valbara, åldersneutrala bildstilar med samma 48 aktivitetsnycklar:

- `simple` / **Tydliga bilder** — renare, hög kontrast och teknisk default.
- `action` / **Aktiva bilder** — mer energi och rörelse, men samma betydelse.

Totalt: 96 transparenta WebP-filer, 512 × 512 px.

## Fallback

1. Eget foto
2. Valt pictogrampaket
3. `simple`
4. Emoji

## Installation

Kopiera `public/` till repo-roten. Slutlig sökväg:

`public/images/child/pictograms/<pack>/<activity-key>@2x.webp`

Barnets ålder ska inte automatiskt låsa paketet. Barn eller förälder väljer det uttryck som fungerar bäst.
