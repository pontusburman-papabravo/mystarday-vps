Du arbetar i `pontusburman-papabravo/mystarday-vps`.

## Uppdrag

Integrera `barnets-samling-activity-pictograms.zip`, uppladdad under `mystarday-vps/public/img`, som två valbara aktivitetspictogrampaket:

- `simple` / Tydliga bilder
- `action` / Aktiva bilder

Paketet innehåller 48 identiska aktivitetsbegrepp i vardera stil, totalt 96 transparenta WebP-filer. `public/img` är endast stagingplats.

## Installera assets

Extrahera till repo-roten så slutlig struktur blir:

```text
public/images/child/pictograms/
  simple/<activity-key>@2x.webp
  action/<activity-key>@2x.webp
```

Ta bort ZIP och temporära extraktionsfiler från committed diff. Verifiera exakt 48 filer per pack, 96 WebP totalt, 512 × 512 och transparenta. Kontrollera att `manifest.json` matchar.

## Inspektera befintlig arkitektur först

Läs särskilt:

```text
docs/child-image-assets.md
public/js/activity-visual.js
public/js/pictogram-registry.js
relevanta API-routes och pictogramtester
```

Befintlig prioritet ska bevaras och utökas till:

```text
eget foto → valt pictogrampaket → simple → befintligt pictogram/emoji
```

Ändra inte schema-, bocknings-, reward-, redeem- eller familjerelationslogik.

## Central config

Skapa ett centralt, testbart lager, exempelvis `public/js/child-pictogram-packs.js`, med `DEFAULT_PACK = "simple"`, `PACKS`, `resolvePack`, `resolveActivityAsset` och `listPacks`. Okänt, tomt eller saknat pack ska bli `simple`. Hårdkoda inte packlogik i varje vy.

## Mappa befintliga icon_key

Inventera de faktiska `icon_key`-värdena i repot och jämför med `manifest.json`. Skapa en central aliasmapp endast där befintliga nycklar skiljer sig, exempelvis `brush_teeth → brush-teeth`. Spara inte bild-URL i schemaaktiviteter. Behåll semantisk `icon_key`. Äldre eller okända nycklar får aldrig krascha.

## Lagring

Återanvänd befintlig JSONB-konfiguration per barn. Föredragen nyckel är `child_view_config.pictogram_pack`. Default är `simple`. Ingen DB-migration om JSONB redan används. Om save-route behövs: acceptera endast `simple` eller `action`, neka extra nycklar, child self eller behörig förälder, och använd atomisk `jsonb_set`.

## UI

Placera en separat inställning nära temaväljaren i Min samling:

```text
Bildstil
○ Tydliga bilder
○ Aktiva bilder
```

Barnets ålder får inte automatiskt styra eller låsa valet. Använd preview + bekräftelse/avbryt enligt befintligt pickermönster. Byte ska uppdatera synliga aktiviteter utan full reload.

## Rendering och fallback

- eget foto har alltid högst prioritet
- valt pack används när asset finns
- saknad action-asset → simple
- saknad simple-asset → befintligt pictogram/emoji
- fasta dimensioner/aspect-ratio, ingen layout shift
- dekorativa bilder `alt=""`; aktivitetens text är det tillgängliga namnet
- lazy-load där lämpligt
- gate OFF/legacy oförändrat

## Cache

Följ befintlig runtime-cache-strategi. Lägg inte nödvändigtvis alla 96 filer i initial precache. Inkrementera SW/cacheversion enligt repo-konvention och dokumentera offlinebeteendet.

## Tester

Verifiera minst:

- 48 nycklar per pack, 96 paths totalt, alla filer finns
- default/okänt/tomt → simple
- central aliasnormalisering
- custom photo vinner
- action används när fil finns
- saknad action → simple
- saknad simple → befintlig emoji
- äldre/okänd icon_key kraschar inte
- endast simple/action accepteras vid save
- extra payloadnycklar nekas
- child kan inte ändra annat barn
- atomisk save bevarar andra configfält
- preview sparar inte; Avbryt återställer; save persisterar

## QA

Uppdatera `docs/qa/barnets-samling-constitution-qa.md` med simple/action, frukost, bada, borsta tänderna, skola, lek och sova, eget foto, fallbackkedjan, iPhone Safari/PWA, Android Chrome/PWA, bottom nav, scroll och legacy gate OFF.

## Kör

```bash
npm run test:gate
npm run check:css
```

Kör även relevanta activity visual-, pictogram-, API- och persistence-tester.

## Scope

Bygg assetinstallation, central pack-resolver, minimal per-child lagring, enkel bildstilsväljare, fallbackkedja, tester och QA-doc. Bygg inte nya aktiviteter, schema-/bockningsändringar, rewards/redeem, tema per aktivitet, automatisk åldersstyrning eller avatar/shop/loot.

Skapa separat branch från uppdaterad main efter theme picker-PR:n, exempel `cursor/child-pictogram-packs`. PR-titel: `Barnets samling — simple and action pictogram packs`. Rapportera branch, SHA, PR-länk, total assetstorlek, cache-strategi, tester, mobil-QA och unmappade icon_key-värden.
